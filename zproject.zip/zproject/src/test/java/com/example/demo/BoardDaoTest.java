package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.dao.BoardDao;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	BoardDao boardDao;
	
//	@Test
	public void doTest() {
		assertNotNull(boardDao);
	}
//	@Test
//	public void countTest() {
//		assertNotEquals(, boardDao.count(null));
//		assertNotEquals(0, boardDao.count('spring');}
	
	@Test
	public void findAllTest() {
		boardDao.findAll(null, 1,10);
		boardDao.findAll("spring", 11,20);
	}
}
