package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.dto.*;
import com.example.demo.entity.Board;

@Mapper
public interface BoardDao {
	// 저장
	
	// 개수
	public Integer count(String writer);
	
	// 페이징
	public List<BoardDto.ForList> findAll(String writer, Integer start, Integer end);
	
	// 업데이트
	
	// 읽기
	
	// 글쓴이 확인
	
	// 삭제
	

	
	
}
