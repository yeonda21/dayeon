package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

import com.example.demo.dto.*;
import com.example.demo.entity.Comment;

@Mapper
public interface CommentDao {
	@SelectKey(statement="select comments_seq.nextval from dual", keyProperty="cno", resultType=Integer.class, before = true)
	@Insert("insert into comments(cno, content, writer, bno) values(#{cno}, #{content}, #{writer}, #{bno})")
	public Integer save(Comment comment);
	
	@Select("select * from comments where bno=#{bno} order by cno desc")
	public List<CommentDto.Read> findByBno(Integer bno);
	
	@Select("select writer from comments where cno=#{cno} and rownum<=1")
	public Optional<String> findWriterById(Integer cno);
	
	@Delete("delete from comments where cno=#{cno}")
	public Integer deleteById(Integer cno);
	
	@Delete("delete from comments where bno=#{bno}")
	public Integer deleteByBno(Integer bno);
}
