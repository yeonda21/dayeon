package com.example.demo;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.bcrypt.*;
import org.springframework.security.crypto.password.*;

@SpringBootApplication
public class LdyBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdyBoardApplication.class, args);
	}
	
	// @Component : 스프링이 빈을 생성 -> componentScan -> 프로젝트의 기본 패키지 
	// @Bean : 프로그래머가 빈을 생성 -> 가져다 사용하는 라이브러리 클래스들
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
