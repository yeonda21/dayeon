package com.example.demo.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class BoardService {
	@Autowired
	private BoardDao boardDao;
	
	public Board write(BoardDto.Write dto, String ioginId) {
		Board board = dto.toEntity().addWriter(ioginId);
		boardDao.save(board);
		return board;
	}

}
