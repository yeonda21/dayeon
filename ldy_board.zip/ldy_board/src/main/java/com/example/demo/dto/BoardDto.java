package com.example.demo.dto;

import java.time.*;
import java.util.*;

import javax.validation.constraints.*;

import com.example.demo.entity.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardDto {
	// 글 목록 출력할 때는 content빼고 읽어온다
	@Data
	public static class ForList {
		private Integer bno;
		private String title;
		private String writer;
		private LocalDateTime writeTime;
		private Integer readCnt;
		private Integer commentCnt;
	}
	
	@Data
	@AllArgsConstructor
	public static class Page {
		private Integer pageno;
		private Integer pagesize;
		private Integer totalcount;
		private Collection<ForList> boardList;
	}
	
	// join dto : 쿼리 한개 or 쿼리 여러개
	// select b.*, c.* from board b left outer join comments c on b.bno=c.bno
	// BoardDto.Read dto = board.findById(bno);	//조인
	
	// BoardDto.Read dto = board.findById(bno); 
		// select * from board where bno=11
	// dto.setComments(commentDao.findByBno(bno));
		// select * from comments where bno=11
	@Data
	public static class Read {
		private Integer bno;
		private String title;
		private String content;
		private String writer;
		private LocalDateTime writeTime;
		private Integer readCnt;
		private Integer goodCnt;
		private Integer badCnt;
		private Integer commentCnt;
		private List<Comment> comments;
	}
	
	//검증 -> ConstraintviolationExceptiom
	@Data
	@Builder
	public static class Write {
		@NotEmpty(message="제목은 필수입력입니다")
		private String title;
		@NotEmpty(message="내용은 필수입력입니다")
		private String content;
		public Board toEntity() {
			return Board.builder().title(title).content(content).build();
		}
	}
	
	@Data
	@Builder
	public static class Update {
		@NotNull(message="글번호는 필수입력입니다")
		private Integer bno;
		@NotEmpty(message="제목은 필수입력입니다")
		private String title;
		@NotEmpty(message="내용은 필수입력입니다")
		private String content;
		public Board toEntity() {
			return Board.builder().title(title).content(content).bno(bno).build();
		}
	}
}