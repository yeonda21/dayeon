package com.example.demo.controller;

import java.security.*;

import javax.validation.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.service.*;

import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.*;
import springfox.documentation.annotations.*;

@Validated
@Controller
public class BoardController {
	@Autowired
	private BoardService service;
	
	// 글 쓰기 
	// 어노테이션은 클래스의 자식뻘. 모든 어노테이션은 value라는 기본값 필드를 가진다
	@PreAuthorize("isAuthenticated()")
	@Operation(summary="5.글 쓰기", description="게시판 글 작성")
	@ApiImplicitParams({
		@ApiImplicitParam(name="title", value="제목", required=true, dataTypeClass=String.class),
		@ApiImplicitParam(name="content", value="내용", required=true, dataTypeClass=String.class),
	})
	@ApiResponses({
		@ApiResponse(code=200, response=RestResponse.class, message="url이 글을 읽을 수 있는 주소"), 
		@ApiResponse(code=409, response=RestResponse.class, message="result에 오류 메시지") 
	})
	@PostMapping(path="/board/new", produces =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> write(
			@ModelAttribute @Valid BoardDto.Write dto, BindingResult br, @ApiIgnore Principal principal) {
			Board board = service.write(dto, principal.getName());
			return ResponseEntity.ok(new RestResponse("ok", board, "board/read?bno="+board.getBno()));
	}
	
}
