package com.example.demo.test;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;

import com.example.demo.dao.*;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	BoardDao dao;
	
	@Test
	public void initTest() {
		System.out.println(dao);
	}
}
	
