package com.example.demo.dto;

import java.time.LocalDate;

import com.example.demo.entity.Board;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardDto {
	@Data
	public static class ListDto {
		private Integer bno;
		private String title;
		private String writer;
		private Integer readCnt;
	}
	
	@Data
	public static class ReadDto {		
		private Integer bno;
		private String title;
		private String writer;
		private Integer readCnt;
		private String content;
		@JsonFormat(pattern="yyyy-MM-dd")
		private LocalDate writeTime;
	}
	
	@Data
	@Builder
	public static class WriteDto {
		private String title;
		private String content;
		private String password;
		private String writer;
		public Board toEntity() {
			return Board.builder().title(title).content(content).password(password).writer(writer).build();
		}
	}
	
	@Data
	@Builder
	public static class UpdateDto {
		private Integer bno;
		private String title;
		private String content;
		private String password;
		public Board toEntity() {
			return Board.builder().title(title).content(content).password(password).bno(bno).build();
		}
	}

	@Data
	@Builder
	public static class DeleteDto {	
		private Integer bno;
		private String password;
	}
}
